const { override } = require("customize-cra");

module.exports = override();
