---
title: Docs Website First Attempt
author: Adam Klein
---

Docs website is up

<!--truncate-->

We decided to use Docusaurus and Github Pages to host our documentation.
Our examples will use parcel for easy setup, and we will embed them using codesandbox inside the docs.
