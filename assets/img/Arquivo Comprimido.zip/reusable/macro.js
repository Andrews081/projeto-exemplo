const macro = require('./src/reuseable.macro');

module.exports = macro;
