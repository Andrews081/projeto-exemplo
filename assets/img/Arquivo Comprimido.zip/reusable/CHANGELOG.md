<a name="1.0.1"></a>
# 1.0.1 (March 3rd, 2020)
* Added description, homepage, license, keywords to package json

<a name="1.0.0"></a>
# 1.0.0 (Feb 17th, 2020)
* Caching previously created components to avoid re-rendering them and losing store state

<a name="1.0.0-alpha.13"></a>
# 1.0.0-alpha.13 (June 14th, 2019)
* Fixed examples, renamed from units to stores
* Added support for debugName for Macro

<a name="1.0.0-alpha.12"></a>
# 1.0.0-alpha.12 (June 11th, 2019)
* Version announced at ReactNext
