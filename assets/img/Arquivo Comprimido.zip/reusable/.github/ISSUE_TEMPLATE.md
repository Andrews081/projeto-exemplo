PLEASE READ CAREFULLY!

# Reproduce
If reporting a bug, or requesting help, please reproduce here using the correct version:
https://codesandbox.io/s/github/reusablejs/reusable/tree/master/examples/basic?fontsize=14&module=%2Fsrc%2Findex.js

# Additional Info
- paste your package.json
- which browser
- paste your code

# Search Issues First
Please look for an answer in the closed and open issues before submitting a new one.
