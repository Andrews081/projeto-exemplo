

const name = "Meu nome é Victor"; // String
const pessoa = {
  "peso": 100,
  "altura": 1.80,
  "nome": "Victor Nery",
  "idade": 22
};
const likeApple = true;
const lista = [ "Meu nome", { "idade": 22 } ]; // array | listagem 
